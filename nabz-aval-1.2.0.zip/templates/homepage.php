<?php /* Template name: Home Page */ ?>

<?php get_header() ?>

<?php cyn_get_page_template('home/hero') ?>

<div class="py-4"></div>

<?php cyn_get_page_template('home/priority') ?>

<div class="py-4"></div>

<?php cyn_get_page_template('home/step') ?>

<div class="py-4"></div>

<?php cyn_get_page_template('home/services'); ?>

<div class="py-4"></div>

<?php cyn_get_page_template('home/videos'); ?>

<div class="py-6"></div>

<?php cyn_get_page_template('home/cta'); ?>

<div class="py-6"></div>

<?php cyn_get_page_template('home/blogs'); ?>

<div class="py-4"></div>

<?php cyn_get_page_template('home/faq'); ?>

<?php get_footer() ?>