# Cyan Digital Marketing Agency

# how to use icons?

with Nucleo app and hotdesk.json located on assets icons folder.
in design you can find icons and then you must create project in Nucleo app.
finally you must export project in svg symbol mode.

then you must created icons.php on partials folder and import by get_template_part() in header.php

note: in production version you must deleted hotdesk.json

# how to add fonts?

there is sample in assets/css/base-tailwind.css file for peyda font

# product version check list

1. run build script
2. change parameters for cyan_theme_init instance on function.php file.
3. remove icons folder from assets.
4. change screenshot.png with last version of design, (1200 \* 900)
5. config plugin0upoda
