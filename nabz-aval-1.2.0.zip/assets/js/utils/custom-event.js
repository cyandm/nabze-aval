export const cynActivate = new CustomEvent('cynActivate', { bubbles: true });
export const cynChangePopup = new CustomEvent('cynChangePopup', {
	bubbles: true,
});
