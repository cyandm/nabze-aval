// const separator = document.querySelectorAll('.comment-submit-btn')

// separator.forEach((el) => {
//     el.innerHTML = '<svg class="icon"><use href="#icon-Send"/></svg>'
// })