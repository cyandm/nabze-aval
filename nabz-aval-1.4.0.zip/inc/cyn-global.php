<?php
//all names in theme

//acf
defined('CYN__PATH') || define('CYN_ACF_PATH', get_stylesheet_directory() . '/inc/acf/');
defined('CYN_ACF_URL') || define('CYN_ACF_URL', get_stylesheet_directory_uri() . '/inc/acf/');


//Post types
define('CYN_FAQ_POST_TYPE', 'cyn_faq');


//Taxonomies
